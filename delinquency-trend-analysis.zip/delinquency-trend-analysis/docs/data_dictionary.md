# Data Dictionary — Delinquency Trend Analysis

## Business Glossary

| Term | Definition |
|------|-----------|
| **DPD** | Days Past Due — number of days since a payment was due but not received |
| **Cohort** | Group of loans disbursed in the same calendar month |
| **Vintage Curve** | Chart showing delinquency rate of a cohort at each loan age |
| **Roll Rate** | Probability that a loan moves from one DPD bucket to a worse bucket |
| **Cure Rate** | % of delinquent loans that return to Current (DPD = 0) status |
| **NPA** | Non-Performing Asset — RBI classifies loans with DPD > 90 as NPA |
| **SMA** | Special Mention Account — early warning stage before NPA |
| **PAR** | Portfolio at Risk — % of portfolio value where DPD exceeds a threshold |
| **EMI** | Equated Monthly Installment — fixed monthly repayment amount |
| **Provisioning** | Funds set aside by lenders to cover expected loan losses |

## SMA Classification (RBI Guidelines)

| Category | DPD Range | Action Required |
|----------|-----------|-----------------|
| Standard | 0 | Normal monitoring |
| SMA-0 | 1–30 | Flag for review |
| SMA-1 | 31–60 | Escalate to collections |
| SMA-2 | 61–90 | Intensive collections, legal notice |
| NPA Sub-standard | 91–365 | Provisioning @ 15% |
| NPA Doubtful | 365+ | Provisioning @ 25–100% |
| Loss Asset | Write-off | 100% provisioned |
