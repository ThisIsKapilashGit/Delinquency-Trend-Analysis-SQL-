# 📊 Delinquency Trend Analysis (SQL)

> **Cohort analysis, DPD movement tracking, and roll rate analysis using MySQL window functions**

A production-grade SQL analytics project that mirrors real-world credit risk workflows used in banks, NBFCs, and fintechs. It covers the full pipeline — data generation, schema design, loading, and analytical SQL queries.

---

## 📁 Project Structure

```
delinquency-trend-analysis/
│
├── data/                            # Generated CSV datasets
│   ├── loans.csv                    # Loan master (500 loans)
│   └── loan_payments.csv            # Monthly payment records (~9,200 rows)
│
├── sql/
│   ├── 01_setup/
│   │   ├── 01_create_tables.sql     # Schema creation
│   │   └── 02_load_data.sql         # LOAD DATA INFILE approach
│   │
│   ├── 02_cohort_analysis/
│   │   └── 01_cohort_analysis.sql   # Vintage curves, cohort NPA rates
│   │
│   ├── 03_dpd_movement/
│   │   └── 01_dpd_movement.sql      # Roll rates, cure rates, flow rates
│   │
│   └── 04_trend_analysis/
│       └── 01_trend_analysis.sql    # MoM trends, PAR, early warning flags
│
├── python/
│   ├── generate_data.py             # Synthetic data generator
│   └── load_to_mysql.py             # Python-based MySQL data loader
│
├── docs/
│   └── data_dictionary.md           # Column definitions and business context
│
├── .gitignore
└── README.md
```

---

## 🗂️ Data Dictionary

### `loans` table

| Column | Type | Description |
|--------|------|-------------|
| `loan_id` | VARCHAR | Unique loan identifier (e.g. LN00001) |
| `customer_id` | VARCHAR | Customer identifier |
| `loan_type` | VARCHAR | Personal / Home / Auto / Business / Education |
| `disbursement_date` | DATE | Date the loan was disbursed |
| `tenure_months` | INT | Total repayment tenure in months |
| `loan_amount` | DECIMAL | Principal loan amount in INR |
| `interest_rate` | DECIMAL | Annual interest rate (%) |
| `risk_bucket` | VARCHAR | Low / Medium / High risk classification |
| `cohort_month` | DATE | First day of the disbursement month (for cohort grouping) |

### `loan_payments` table

| Column | Type | Description |
|--------|------|-------------|
| `payment_id` | INT | Unique payment record identifier |
| `loan_id` | VARCHAR | Reference to loans table |
| `report_month` | DATE | First day of the reporting month |
| `due_date` | DATE | EMI due date |
| `emi_amount` | DECIMAL | Equated Monthly Installment amount |
| `dpd` | INT | Days Past Due at time of reporting |
| `dpd_bucket` | VARCHAR | DPD classification bucket (see below) |
| `payment_status` | VARCHAR | Paid / Overdue |

### DPD Bucket Classification

| Bucket | DPD Range | Meaning |
|--------|-----------|---------|
| Current | 0 | No overdue — performing loan |
| DPD 1-30 | 1–30 | Early delinquency — SMA-0 |
| DPD 31-60 | 31–60 | Moderate delinquency — SMA-1 |
| DPD 61-90 | 61–90 | Severe delinquency — SMA-2 |
| DPD 91-180 | 91–180 | NPA territory |
| DPD 180+ | >180 | Deep NPA — likely write-off |

---

## 🚀 Getting Started

### Prerequisites

- MySQL 8.0+
- Python 3.9+
- `pip install python-dateutil mysql-connector-python`

### Step 1 — Generate the Data

```bash
cd python
python generate_data.py
```

This creates `data/loans.csv` and `data/loan_payments.csv`.

### Step 2 — Create the Schema

Run in MySQL Workbench or CLI:

```sql
source sql/01_setup/01_create_tables.sql;
```

### Step 3 — Load the Data

**Option A — Python loader (recommended):**
```bash
# Update DB_CONFIG in load_to_mysql.py with your credentials first
python python/load_to_mysql.py
```

**Option B — MySQL LOAD DATA INFILE:**
```sql
-- Update file paths in the script first
source sql/01_setup/02_load_data.sql;
```

### Step 4 — Run the Analysis

```sql
-- Cohort / Vintage Analysis
source sql/02_cohort_analysis/01_cohort_analysis.sql;

-- DPD Movement & Roll Rates
source sql/03_dpd_movement/01_dpd_movement.sql;

-- Portfolio Trend Analysis
source sql/04_trend_analysis/01_trend_analysis.sql;
```

---

## 📈 Key Analyses Covered

### 1. Cohort / Vintage Analysis
- Groups loans by disbursement month (cohort)
- Tracks delinquency rate at each loan age (month 1, 2, 3...)
- Produces vintage curves used by credit risk teams to compare underwriting quality across cohorts

### 2. DPD Movement & Roll Rates
- **Roll Rate Matrix** — transition probability between DPD buckets month-over-month
- **Cure Rate** — % of delinquent loans returning to Current status
- **Flow Rate** — speed of deterioration across the DPD spectrum

### 3. Portfolio Trend Analysis
- Month-over-Month delinquency rate changes
- 3-month rolling average (smooths noise)
- Risk bucket and loan type segmentation trends
- **Portfolio at Risk (PAR-30, PAR-60, PAR-90)** — standard regulatory metric
- **Early Warning System** — flags loans with rapid DPD escalation

---

## 🔧 SQL Concepts Demonstrated

| Concept | Used In |
|---------|---------|
| `LAG()` / `LEAD()` window functions | Roll rates, MoM trend, cure rates |
| `SUM() OVER (PARTITION BY ...)` | Running totals, bucket percentages |
| `RANK()` / `PERCENT_RANK()` | Worst month identification, loan type ranking |
| `AVG() OVER (ROWS BETWEEN ...)` | Rolling 3-month averages |
| CTEs (`WITH` clause) | Multi-step cohort and roll rate logic |
| `TIMESTAMPDIFF()` | Loan age computation |
| `CASE WHEN` aggregations | DPD bucket classification and KPI pivots |
| `FIELD()` for custom ordering | Correct DPD bucket sort order |

---

## 💡 Business Context

This project replicates analyses performed daily in **credit risk, collections, and portfolio management teams** at:
- Commercial Banks
- Non-Banking Financial Companies (NBFCs)
- Microfinance Institutions (MFIs)
- Fintech Lenders

**Key decisions driven by these analyses:**
- Loan loss provisioning (IFRS 9 / Ind AS 109)
- Collections strategy prioritisation
- Early warning and pre-delinquency intervention
- Underwriting policy tightening / loosening

---

## 🤝 Contributing

Pull requests are welcome. For major changes, please open an issue first.

---

## 📄 License

MIT License — free to use for learning and portfolio purposes.
